DATABASE -DATA, ANONYMIZATION SOFTWARE

> Please fill the settings file, with your tables & columns, before executing the software.
> All data defined to be anonymized will not be recoverable after executing this program.

[>]TERMS OF USE[<]

>> You assume any and all risks associated with the use of the software. 
>> All Executing of this software is run with the USER's full agreement acknowledging their actions cannot be reversed, and thus executing this software causes irreversible changes to the data in a database.
>> I as the creator will take no responsibility for the actions of the user, using this software on their database(s).